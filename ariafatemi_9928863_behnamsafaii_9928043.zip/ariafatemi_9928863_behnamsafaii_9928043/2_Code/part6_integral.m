clc;
clear;
close all;

% Define parameters
M = 1000 * 10^(-3);       % Mass (kg)
b = 1 * 10^(-3);          % Width (m)
h = 2 * 10^(-2);          % Height (m)
E = 10 * 10^9;            % Young's modulus (Pa)
L = 0.8;                  % Length (m)
kisi = 0.5;               % Damping ratio

% Calculate inertias and other parameters
I = b * h^3 / 12;                % Moment of inertia (m^4)
k_stiff = 3 * E * I / (L^3);     % Stiffness (N/m)
j_arm = M * L^2 / 2;             % Arm inertia (kg.m^2)
j_eq = 1.5 * j_arm;              % Equivalent inertia (kg.m^2)
B_eq = 2 * kisi * sqrt(k_stiff * M); % Equivalent damping (N.m.s)

% State-space representation matrices
A = [0 0 1 0 0;
     0 0 0 1 0;
     0 k_stiff / j_eq -B_eq / j_eq 0 0;
     0 -(k_stiff * ((1 / j_eq) + (1 / j_arm))) B_eq / j_eq 0 0
     1 0 0 0 0]

B = [0 0;
     0 0;
     1 / j_eq -L / j_eq;
     -1 / j_eq L * ((1 / j_eq) + (1 / j_arm));
     0 0];

C = [1 0 0 0 1;
     0 1 0 0 1];

D = [0 0;
     0 0];
eig(A)
pd=[-3-3*i -12+12*i -12-12*i -10 -1];
f=[5;2];
b1=B*f;
k=acker(A,b1,pd)
K=f*k