clc;
clear;
close all;

% Define parameters
M = 1000 * 10^(-3);       % Mass (kg)
b = 1 * 10^(-3);          % Width (m)
h = 2 * 10^(-2);          % Height (m)
E = 10 * 10^9;            % Young's modulus (Pa)
L = 0.8;                  % Length (m)
kisi = 0.5;               % Damping ratio

% Calculate inertias and other parameters
I = b * h^3 / 12;                % Moment of inertia (m^4)
k_stiff = 3 * E * I / (L^3);     % Stiffness (N/m)
j_arm = M * L^2 / 2;             % Arm inertia (kg.m^2)
j_eq = 1.5 * j_arm;              % Equivalent inertia (kg.m^2)
B_eq = 2 * kisi * sqrt(k_stiff * M); % Equivalent damping (N.m.s)

% State-space representation matrices
A = [0 0 1 0;
     0 0 0 1;
     0 k_stiff / j_eq -B_eq / j_eq 0;
     0 -(k_stiff * ((1 / j_eq) + (1 / j_arm))) B_eq / j_eq 0];

B = [0 0;
     0 0;
     1 / j_eq -L / j_eq;
     -1 / j_eq L * ((1 / j_eq) + (1 / j_arm))] ;

C = [1 0 0 0;
     0 1 0 0];

D = [0 0;
     0 0];
An=[A zeros(4,2);C zeros(2,2)];
Bn=[B;zeros(2,2)];
new=rank(ctrb(An,Bn));
pd=[-3 -12+12*1i -12-12*1i -10];
f=[5;1];
b1=B*f;
k=acker(A,b1,pd);
K1=f*k;
x1_max=0.5;
x2_max=0.4;
x3_max=1;
x4_max=1;
u1_max=100;
u2_max=10;
Q=[ (1/x1_max)^2 0 0 0;
    0 (1/x2_max)^2 0 0
    0 0 (1/x3_max)^2 0
    0 0 0 (1/x4_max)^2];
R=[(1/u1_max)^2 0;0 (1/u2_max)^2];
K2=lqr(A,B,Q,R);
F=[1;1];
c1=C'*F;
poles=[-6 -20+20*i -20-20*i -30];
g = acker(A',c1,poles);
G = F*g;
G = G'

