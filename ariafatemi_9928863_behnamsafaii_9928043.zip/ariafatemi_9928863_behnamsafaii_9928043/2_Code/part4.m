clc;
clear;
close all;

% Define parameters
M = 1000 * 10^(-3);       % Mass (kg)
b = 1 * 10^(-3);          % Width (m)
h = 2 * 10^(-2);          % Height (m)
E = 10 * 10^9;            % Young's modulus (Pa)
L = 0.8;                  % Length (m)
kisi = 0.5;               % Damping ratio

% Calculate inertias and other parameters
I = b * h^3 / 12;                % Moment of inertia (m^4)
k_stiff = 3 * E * I / (L^3);     % Stiffness (N/m)
j_arm = M * L^2 / 2;             % Arm inertia (kg.m^2)
j_eq = 1.5 * j_arm;              % Equivalent inertia (kg.m^2)
B_eq = 2 * kisi * sqrt(k_stiff * M); % Equivalent damping (N.m.s)

% State-space representation matrices
A = [0 0 1 0;
     0 0 0 1;
     0 k_stiff / j_eq -B_eq / j_eq 0;
     0 -(k_stiff * ((1 / j_eq) + (1 / j_arm))) B_eq / j_eq 0];

B = [0 0;
     0 0;
     1 / j_eq -L / j_eq;
     -1 / j_eq L * ((1 / j_eq) + (1 / j_arm))];

C = [1 0 0 0;
     0 1 0 0];

% Calculate controllability and observability
co = ctrb(A, B);
rank_controlability = rank(co);

O = obsv(A, C);
rank_observability = rank(O);

% Compute Jordan form of A
[T, J] = jordan(A);

% Display results
disp('Controlability Matrix Rank:');
disp(rank_controlability);

disp('Observability Matrix Rank:');
disp(rank_observability);

disp('Transformation Matrix T (Jordan Form):');
disp(T);

% Compute transformed system matrices
A_new = J;
B_new = inv(T) * B;
C_new = C * T;

disp('A_new = ');
disp(A_new);

disp('B_new = ');
disp(B_new);

disp('C_new = ');
disp(C_new);

% Compute left null space of A
null_space_A = null(A, 'r');

% Select a non-zero vector from the null space
x0 = null_space_A(:, 1);  % Choose the first vector in the null space

% Example: Simulate the system response with the chosen initial condition x0
tspan = 0:0.01:10;  % Time span for simulation
[t, x] = ode45(@(t,x) A*x, tspan, x0);

% Plot the states over time
figure;
plot(t, x);
xlabel('Time');
ylabel('State Variables');
legend('x1', 'x2', 'x3', 'x4');  % Adjust legends based on your system's states
title('System Response with Non-Exciting Initial Condition');

% Display controlability and observability matrices
disp('Controlability Matrix:');
disp(co);

disp('Observability Matrix:');
disp(O);
